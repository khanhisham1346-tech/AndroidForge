package com.florite.xpanel

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {
    private lateinit var content: FrameLayout
    private lateinit var navigation: LinearLayout
    private val prefs by lazy { getSharedPreferences("florite_settings", Context.MODE_PRIVATE) }
    private val pages = listOf("Home", "Aim Demo", "ESP Demo", "Shizuku", "Settings")
    private var currentPage = "Home"
    private var lightTheme = false
    private val red = 0xFFFF3045.toInt()
    private val dark = 0xFF090909.toInt()
    private val cardColor = 0xFF171719.toInt()
    private val textColor = 0xFFF7F7F9.toInt()
    private val muted = 0xFFA8A8B0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        navigation = findViewById(R.id.navigation)
        lightTheme = prefs.getBoolean("light_theme", false)
        buildNavigation()
        showPage("Home")
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun buildNavigation() {
        navigation.removeAllViews()
        pages.forEach { page ->
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.text = page
            b.textSize = 11f
            b.isAllCaps = false
            b.setTextColor(if (page == currentPage) red else textColor)
            b.strokeColor = android.content.res.ColorStateList.valueOf(if (page == currentPage) red else 0xFF38383D.toInt())
            b.cornerRadius = dp(14)
            b.setOnClickListener { showPage(page) }
            navigation.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)).apply {
                marginStart = dp(3); marginEnd = dp(3)
            })
        }
    }

    private fun showPage(page: String) {
        currentPage = page
        buildNavigation()
        content.removeAllViews()
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(body)
        content.addView(scroll)
        when (page) {
            "Home" -> home(body)
            "Aim Demo" -> aim(body)
            "ESP Demo" -> esp(body)
            "Shizuku" -> shizuku(body)
            "Settings" -> settings(body)
        }
    }

    private fun heading(body: LinearLayout, title: String, subtitle: String) {
        val top = TextView(this).apply {
            text = "FLORITE  /  X PANEL"
            textSize = 11f; setTextColor(red); letterSpacing = .18f
        }
        body.addView(top)
        body.addView(TextView(this).apply {
            text = title; textSize = 29f; setTextColor(if (lightTheme) 0xFF171717.toInt() else textColor)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(3))
        })
        body.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(muted) })
        space(body, 18)
    }

    private fun card(body: LinearLayout, title: String, subtitle: String? = null): LinearLayout {
        val c = MaterialCardView(this).apply {
            radius = dp(18).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(if (lightTheme) 0xFFFFFFFF.toInt() else cardColor)
            strokeWidth = dp(1)
            strokeColor = if (lightTheme) 0xFFE5E5E8.toInt() else 0xFF29292E.toInt()
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }
        inner.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(if (lightTheme) 0xFF171717.toInt() else textColor)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        if (subtitle != null) inner.addView(TextView(this).apply {
            text = subtitle; textSize = 12f; setTextColor(muted); setPadding(0, dp(4), 0, 0)
        })
        c.addView(inner)
        body.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        return inner
    }

    private fun space(body: LinearLayout, h: Int) {
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(if (lightTheme) 0xFF292929.toInt() else textColor)
    }

    private fun home(body: LinearLayout) {
        heading(body, "Gaming dashboard", "A clean, local-only visual control panel")
        val hero = card(body, "SYSTEM ONLINE", "FLORITE X • Visual demo mode only")
        hero.addView(TextView(this).apply {
            text = "●  READY"; setTextColor(red); textSize = 13f
            setPadding(0, dp(12), 0, 0)
        })
        val info = card(body, "DEVICE INFORMATION", "Reported by Android")
        info.addView(label("Device: ${Build.MANUFACTURER} ${Build.MODEL}"))
        info.addView(label("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})").apply { setPadding(0, dp(7), 0, 0) })
        info.addView(label("App version: 1.0 • No root required").apply { setPadding(0, dp(7), 0, 0) })
        val status = card(body, "MODULE STATUS")
        listOf("Aim controls" to "Visual demo", "ESP canvas" to "Simulation only", "Settings storage" to "Local preferences").forEach { (a,b) ->
            status.addView(label("$a     •     $b").apply { setPadding(0, dp(7), 0, dp(4)) })
        }
        val button = actionButton("OPEN ESP DEMO")
        button.setOnClickListener { showPage("ESP Demo") }
        body.addView(button, matchWrap())
    }

    private fun aim(body: LinearLayout) {
        heading(body, "Aim settings", "Demo controls only — these do not affect any game")
        val c = card(body, "VISUAL AIM LAB", "Values are stored locally on this device.")
        demoSwitch(c, "Aim Neck", "aim_neck", false)
        demoSwitch(c, "Aim Silent", "aim_silent", false)
        addSlider(c, "FOV", "fov", 10f, 180f, 90f)
        addSlider(c, "Sensitivity", "sensitivity", 1f, 100f, 50f)
        c.addView(TextView(this).apply {
            text = "Demo only. No game process, memory, input or network is accessed."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(14), 0, 0)
        })
    }

    private fun addSlider(parent: LinearLayout, title: String, key: String, min: Float, max: Float, default: Float) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = label(title)
        val value = label(prefs.getFloat(key, default).toInt().toString()).apply { setTextColor(red) }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(value)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val slider = Slider(this).apply {
            valueFrom = min; valueTo = max; stepSize = 1f
            value = prefs.getFloat(key, default).coerceIn(min, max)
            trackActiveTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
        }
        slider.addOnChangeListener { _, v, fromUser ->
            value.text = v.toInt().toString()
            if (fromUser) prefs.edit().putFloat(key, v).apply()
        }
        parent.addView(slider, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun demoSwitch(parent: LinearLayout, title: String, key: String, default: Boolean) {
        val s = SwitchCompatFactory.create(this).apply {
            text = title; textSize = 14f; setTextColor(if (lightTheme) 0xFF292929.toInt() else textColor)
            isChecked = prefs.getBoolean(key, default)
            thumbTintList = android.content.res.ColorStateList.valueOf(if (isChecked) red else 0xFFCCCCCC.toInt())
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        parent.addView(s, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun esp(body: LinearLayout) {
        heading(body, "ESP simulation", "Illustrative canvas with generated objects only")
        val c = card(body, "OVERLAY OPTIONS", "Toggle markers in the local preview")
        demoSwitch(c, "Box markers", "esp_box", true)
        demoSwitch(c, "Direction lines", "esp_line", true)
        demoSwitch(c, "Location labels", "esp_location", true)
        val previewCard = card(body, "LIVE CANVAS DEMO", "Objects are randomly placed illustrations, not game data.")
        val preview = DemoCanvas(this) { key -> prefs.getBoolean(key, true) }
        previewCard.addView(preview, LinearLayout.LayoutParams(-1, dp(290)))
        val refresh = actionButton("REFRESH SIMULATION")
        refresh.setOnClickListener { preview.invalidate(); Toast.makeText(this, "Demo preview refreshed", Toast.LENGTH_SHORT).show() }
        body.addView(refresh, matchWrap())
    }

    private fun shizuku(body: LinearLayout) {
        heading(body, "Shizuku status", "Read-only availability check")
        val installed = try {
            if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getPackageInfo("moe.shizuku.privileged.api",
                    android.content.pm.PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            }
            true
        } catch (_: Exception) { false }
        val c = card(body, if (installed) "SHIZUKU APP DETECTED" else "SHIZUKU NOT DETECTED",
            if (installed) "The Shizuku app package is installed." else "The Shizuku app package was not found on this device.")
        c.addView(TextView(this).apply {
            text = if (installed) "Package detected. Service running/permission status is not verified." else "Install and start Shizuku separately if you use it for legitimate supported apps."
            textSize = 13f; setTextColor(muted); setPadding(0, dp(12), 0, 0)
        })
        val check = actionButton("CHECK AGAIN")
        check.setOnClickListener { showPage("Shizuku") }
        body.addView(check, matchWrap())
    }

    private fun settings(body: LinearLayout) {
        heading(body, "Settings", "Personalize the panel and manage saved values")
        val c = card(body, "APPEARANCE")
        val theme = SwitchCompatFactory.create(this).apply {
            text = "Light theme"; textSize = 14f; setTextColor(if (lightTheme) 0xFF292929.toInt() else textColor)
            isChecked = lightTheme
            setOnCheckedChangeListener { _, checked ->
                lightTheme = checked
                prefs.edit().putBoolean("light_theme", checked).apply()
                showPage("Settings")
            }
        }
        c.addView(theme)
        val save = actionButton("SAVE SETTINGS")
        save.setOnClickListener {
            prefs.edit().putBoolean("aim_neck", prefs.getBoolean("aim_neck", false))
                .putBoolean("aim_silent", prefs.getBoolean("aim_silent", false)).apply()
            Toast.makeText(this, "Settings saved on this device", Toast.LENGTH_SHORT).show()
        }
        body.addView(save, matchWrap())
        val reset = actionButton("RESET DEMO VALUES")
        reset.setOnClickListener {
            prefs.edit().remove("aim_neck").remove("aim_silent").remove("fov").remove("sensitivity")
                .remove("esp_box").remove("esp_line").remove("esp_location").apply()
            Toast.makeText(this, "Demo values reset", Toast.LENGTH_SHORT).show()
            showPage("Settings")
        }
        body.addView(reset, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        body.addView(TextView(this).apply {
            text = "All demo settings persist locally using Android SharedPreferences. Reset clears demo values; the theme choice is retained."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(14), 0, 0)
        })
    }

    private fun actionButton(text: String) = MaterialButton(this).apply {
        this.text = text; isAllCaps = false; textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        backgroundTintList = android.content.res.ColorStateList.valueOf(red)
        cornerRadius = dp(15)
        elevation = dp(5).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, dp(50))

    class DemoCanvas(context: Context, val enabled: (String) -> Boolean) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val red = 0xFFFF3045.toInt()
        private val muted = 0xFFB0B0B8.toInt()
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0xFF101013.toInt())
            paint.color = 0xFF24242A.toInt()
            for (x in 0..8) canvas.drawLine(width * x / 8f, 0f, width * x / 8f, height.toFloat(), paint)
            for (y in 0..10) canvas.drawLine(0f, height * y / 10f, width.toFloat(), height * y / 10f, paint)
            val boxes = listOf(
                RectF(width*.13f, height*.20f, width*.34f, height*.56f),
                RectF(width*.57f, height*.27f, width*.78f, height*.64f),
                RectF(width*.39f, height*.48f, width*.51f, height*.77f)
            )
            boxes.forEachIndexed { i, r ->
                val cx = r.centerX()
                if (enabled("esp_line")) {
                    paint.color = red; paint.strokeWidth = 2f
                    canvas.drawLine(width*.5f, height*.96f, cx, r.bottom, paint)
                }
                if (enabled("esp_box")) {
                    paint.color = red; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
                    canvas.drawRoundRect(r, 8f, 8f, paint)
                    paint.style = Paint.Style.FILL
                }
                if (enabled("esp_location")) {
                    paint.color = muted; paint.textSize = 11f
                    canvas.drawText("SIM ${i+1}", r.left, r.top - 8f, paint)
                }
            }
            paint.color = muted; paint.textSize = 10f
            canvas.drawText("SIMULATED SCENE • NO GAME DATA", 12f, height - 12f, paint)
        }
    }
}

private object SwitchCompatFactory {
    fun create(context: Context): android.widget.Switch = android.widget.Switch(context)
}
