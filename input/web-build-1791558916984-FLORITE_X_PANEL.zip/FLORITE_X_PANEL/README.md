# FLORITE X PANEL

A compact Kotlin + XML Android Studio project for Android 8.0 (API 26) and newer.
It is a standalone visual demo panel. Aim controls are local UI values only; ESP is a simulated Canvas scene.
It does not access game memory, alter games, bypass anti-cheat, require root, or claim Shizuku service access.

## Build the APK
1. Install Android Studio (stable) and Android SDK Platform 35.
2. Open the `FLORITE_X_PANEL` folder in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show a notification with **Locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- JDK 17 is required; Android Studio's bundled JDK is recommended.
- No Gradle wrapper JAR is bundled. Android Studio can import the project and provision the configured Gradle version, or you can run it from an installed Gradle 8.9+ environment.
- Settings use SharedPreferences and survive app restarts.
- Shizuku screen checks only whether the Shizuku package is installed; it does not pretend to verify a running service.
